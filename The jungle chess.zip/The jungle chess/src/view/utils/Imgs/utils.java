package view.utils.Imgs;

import java.awt.*;

public class utils {
    public static Image bg=Toolkit.getDefaultToolkit().getImage("imgs/1.png");
}
